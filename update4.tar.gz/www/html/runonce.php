<?php

function runonce() {
	chdir('/home/pi/sh/');
	$sh= shell_exec('sudo ./runonce.sh');
	unlink('/home/pi/www/html/runonce.php');
	header("Location: index.html");
	die();
}

?>
