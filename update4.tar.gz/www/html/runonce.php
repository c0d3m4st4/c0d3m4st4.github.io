<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


function runonce() {
	chdir('/home/pi/sh/');
	$sh= shell_exec('sudo ./runonce.sh');
	unlink('/home/pi/www/html/runonce.php');
	header("Location: index.html");
	die();
}

?>
