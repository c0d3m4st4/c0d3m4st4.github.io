#!/bin/bash

sudo /usr/sbin/iw wlan0 set power_save on
ls -l > ./ls.out

